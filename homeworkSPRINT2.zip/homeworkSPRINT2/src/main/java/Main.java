import model.Apple;
import model.Food;
import model.Meat;
import service.ShoppingCart;

import static model.constants.Colour.GREEN_COLOUR;
import static model.constants.Colour.RED_COLOUR;

public class Main {
    public static void main(String[] args) {
        Food meat = new Meat(5, 100.0);
        Food redApple = new Apple(10, 50.0, "red");
        Food greenApple = new Apple(8, 60.0, "green");

        Food[] meal = {meat, redApple, greenApple};

        ShoppingCart shoppingCart = new ShoppingCart(meal);
        System.out.println("Сумма товаров без скидки: "+shoppingCart.getTotalPriceWithoutDiscount());
        System.out.println("Сумма товаров со скидкой: "+shoppingCart.getTotalPriceWithDiscount());
        System.out.println("Сумма вегетарианских продуктов без скидки: "+shoppingCart.getTotalVegetarianPriceWithoutDiscount());
    }
}
