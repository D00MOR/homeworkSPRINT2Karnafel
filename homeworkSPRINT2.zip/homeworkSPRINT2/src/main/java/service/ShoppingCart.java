package service;

import model.Food;

public class ShoppingCart {
    private Food[] meal;
    public ShoppingCart(Food[] meal) {
        this.meal = meal;
    }

    public double getTotalPriceWithoutDiscount() {
        double countPrice = 0.0;
        for (Food food : meal) {
            countPrice += food.getPrice() * food.getAmount();
        }
        return countPrice;
    }

    public double getTotalPriceWithDiscount() {
        double countPrice = 0.0;
        for (Food food : meal) {
            countPrice += (food.getPrice() - discountSum(food)) * food.getAmount();
        }
        return countPrice;
    }

    public double getTotalVegetarianPriceWithoutDiscount() {
        double countPrice = 0.0;
        for (Food food : meal) {
            if (food.getVegetarian()) {
                countPrice += food.getPrice() * food.getAmount();
            }
        }
        return countPrice;
    }
    private double discountSum(Food food) {
        return food.getPrice()/100*food.getDiscount();
    }
}
