package model;

import static model.constants.Colour.RED_COLOUR;
import static model.constants.Discount.DISCOUNT_FOR_RED_APPLES;
import static model.constants.Discount.TOTAL_DISCOUNT;

public class Apple extends Food{
    private String colour;

    public Apple(int amount, double price, String colour) {
        super(amount, price);
        this.isVegetarian = true;
        this.colour = colour;
    }

    @Override
    public double getDiscount() {
        if (colour==RED_COLOUR) {
            return DISCOUNT_FOR_RED_APPLES;
        }
        return TOTAL_DISCOUNT;
    }
}
