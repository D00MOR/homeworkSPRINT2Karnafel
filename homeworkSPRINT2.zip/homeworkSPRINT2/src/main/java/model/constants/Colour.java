package model.constants;

public class Colour {
    public static final String RED_COLOUR = "red";
    public static final String GREEN_COLOUR = "green";
}
