package model.constants;

public class Discount {
    public static final double TOTAL_DISCOUNT = 0.0;
    public static final double DISCOUNT_FOR_RED_APPLES = 60.0;
}
