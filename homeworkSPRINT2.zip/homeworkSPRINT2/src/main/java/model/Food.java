package model;

import static model.constants.Discount.TOTAL_DISCOUNT;

public abstract class Food implements Discountable {
    protected int amount;
    protected double price;
    protected boolean isVegetarian;

    protected Food(int amount, double price) {
        this.amount = amount;
        this.price = price;
    }

    @Override
    public double getDiscount() {
        return TOTAL_DISCOUNT;
    }
    public int getAmount() {
        return amount;
    }
    public double  getPrice() {
        return price;
    }
    public boolean getVegetarian(){
        return isVegetarian;
    }
}
